<!-- ********************************************************************** -->
<!--                                                                        -->
<!-- Copyright (c) 2003-2010 ZeroC, Inc. All rights reserved.               -->
<!--                                                                        -->
<!-- This copy of Ice is licensed to you under the terms described in the   -->
<!-- ICE_LICENSE file included in this distribution.                        -->
<!--                                                                        -->
<!-- ********************************************************************** -->

<?
echo "value = ",PHP_CONFIG_FILE_PATH,"\n";
?>
